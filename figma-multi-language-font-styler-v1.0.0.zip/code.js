"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// 主要程式碼檔案 (code.ts)
figma.showUI(__html__, { width: 280, height: 560 });
// 初始化數據
let textStyles = [];
let presets = [];
let availableFonts = [];
let fontFamiliesData = {};
// 即時轉換相關變量 (總是啟用)
let isPluginModifying = false;
let lastAppliedSettings = null;
let debounceTimeout = null;
// 防抖函數
function debounce(func, delay) {
    return (...args) => {
        if (debounceTimeout) {
            clearTimeout(debounceTimeout);
        }
        debounceTimeout = setTimeout(() => func.apply(null, args), delay);
    };
}
// 針對特定文字節點的即時轉換 - 使用最後套用的設定
function triggerRealtimeConversionForNode(textNode) {
    return __awaiter(this, void 0, void 0, function* () {
        if (isPluginModifying) {
            return;
        }
        // 如果沒有任何設定，就不進行轉換
        if (!lastAppliedSettings) {
            return;
        }
        try {
            isPluginModifying = true;
            // 使用最後套用的設定
            const chineseSettings = lastAppliedSettings.chineseSettings;
            const englishSettings = lastAppliedSettings.englishSettings;
            const numberSettings = lastAppliedSettings.numberSettings;
            // 首先載入節點中所有現有的字體
            yield loadExistingFontsInNode(textNode);
            const characters = textNode.characters;
            const segments = analyzeTextSegments(characters, chineseSettings, englishSettings, numberSettings);
            // 載入所需字體
            const fontsToLoad = new Set();
            for (const segment of segments) {
                if (segment.settings && segment.settings.type === 'font' && segment.settings.fontFamily) {
                    let fontWeight = segment.settings.fontWeight;
                    if (!fontWeight) {
                        let originalWeight = null;
                        try {
                            const firstCharFont = textNode.getRangeFontName(segment.start, segment.start + 1);
                            if (typeof firstCharFont === 'object' && firstCharFont.style) {
                                originalWeight = firstCharFont.style;
                            }
                        }
                        catch (error) {
                            // 忽略錯誤
                        }
                        fontWeight = getClosestFontWeight(segment.settings.fontFamily, fontFamiliesData, originalWeight || undefined);
                    }
                    if (fontWeight) {
                        fontsToLoad.add(`${segment.settings.fontFamily}|${fontWeight}`);
                    }
                }
            }
            // 載入字體
            const fontLoadPromises = Array.from(fontsToLoad).map(fontKey => {
                const [family, style] = fontKey.split('|');
                return figma.loadFontAsync({ family, style }).catch(() => null);
            });
            yield Promise.all(fontLoadPromises);
            // 套用樣式
            for (const segment of segments) {
                if (segment.settings) {
                    try {
                        if (segment.settings.type === 'textStyle' && segment.settings.styleId) {
                            textNode.setRangeTextStyleId(segment.start, segment.end, segment.settings.styleId);
                        }
                        else if (segment.settings.type === 'font' && segment.settings.fontFamily) {
                            let fontWeight = segment.settings.fontWeight;
                            if (!fontWeight) {
                                let originalWeight = null;
                                try {
                                    const firstCharFont = textNode.getRangeFontName(segment.start, segment.start + 1);
                                    if (typeof firstCharFont === 'object' && firstCharFont.style) {
                                        originalWeight = firstCharFont.style;
                                    }
                                }
                                catch (error) {
                                    // 忽略錯誤
                                }
                                fontWeight = getClosestFontWeight(segment.settings.fontFamily, fontFamiliesData, originalWeight || undefined);
                            }
                            if (fontWeight) {
                                textNode.setRangeFontName(segment.start, segment.end, {
                                    family: segment.settings.fontFamily,
                                    style: fontWeight
                                });
                                // 設置字體大小
                                if (segment.settings.fontSize && segment.settings.fontSize !== 'keep') {
                                    const fontSize = parseInt(segment.settings.fontSize);
                                    if (!isNaN(fontSize)) {
                                        textNode.setRangeFontSize(segment.start, segment.end, fontSize);
                                    }
                                }
                            }
                        }
                    }
                    catch (error) {
                        console.error('即時轉換段落處理錯誤:', error);
                    }
                }
            }
        }
        catch (error) {
            console.error('即時轉換失敗:', error);
        }
        finally {
            isPluginModifying = false;
        }
    });
}
// 建立防抖版本的即時轉換函數
const debouncedRealtimeConversionForNode = debounce(triggerRealtimeConversionForNode, 400);
// 載入已有的 Text Styles
function loadTextStyles() {
    return __awaiter(this, void 0, void 0, function* () {
        const styles = yield figma.getLocalTextStylesAsync();
        textStyles = styles.map(style => ({
            id: style.id,
            name: style.name
        }));
        figma.ui.postMessage({
            type: 'textStyles',
            styles: textStyles
        });
    });
}
// 載入可用字體
function loadAvailableFonts() {
    return __awaiter(this, void 0, void 0, function* () {
        const fonts = yield figma.listAvailableFontsAsync();
        availableFonts = fonts.map(font => ({
            family: font.fontName.family,
            style: font.fontName.style
        }));
        // 將字體按照 family 分組
        const fontFamilies = {};
        for (const font of availableFonts) {
            if (!fontFamilies[font.family]) {
                fontFamilies[font.family] = [];
            }
            fontFamilies[font.family].push(font.style);
        }
        // 儲存字體家族數據供後續使用
        fontFamiliesData = fontFamilies;
        figma.ui.postMessage({
            type: 'availableFonts',
            fonts: fontFamilies
        });
    });
}
// 載入已保存的預設集
function loadPresets() {
    return __awaiter(this, void 0, void 0, function* () {
        // 內建預設組合 - 不可刪除且永遠排第一個
        const builtinPreset = {
            id: 'builtin-noto-roboto',
            name: '思源宋+Roboto Slab',
            isBuiltin: true, // 標記為內建組合
            chineseSettings: {
                type: 'font',
                fontFamily: 'Noto Serif TC',
                fontWeight: '', // 維持原本字重
                fontSize: 'keep' // 維持原本字型大小
            },
            englishSettings: {
                type: 'font',
                fontFamily: 'Roboto Slab',
                fontWeight: '', // 維持原本字重
                fontSize: 'keep' // 維持原本字型大小
            },
            numberSettings: {
                type: 'font',
                fontFamily: 'Roboto Slab', // 同英文字型
                fontWeight: '', // 維持原本字重
                fontSize: 'keep' // 維持原本字型大小
            }
        };
        const savedPresets = (yield figma.clientStorage.getAsync('languagePresets')) || [];
        // 將內建組合放在第一個，後面接使用者儲存的組合
        presets = [builtinPreset, ...savedPresets];
        figma.ui.postMessage({
            type: 'presets',
            presets: presets
        });
    });
}
// 字符類型檢測函數
function getCharacterType(char) {
    // 中文字符 (包含繁體、簡體中文、日文漢字等)
    if (/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/.test(char)) {
        return 'chinese';
    }
    // 英文字符 (包含大小寫字母)
    if (/[a-zA-Z]/.test(char)) {
        return 'english';
    }
    // 數字字符
    if (/[0-9]/.test(char)) {
        return 'number';
    }
    // 其他字符 (標點符號、空格等)
    return 'other';
}
// 分析文字段落函數
function analyzeTextSegments(characters, chineseSettings, englishSettings, numberSettings) {
    const segments = [];
    let currentSegment = null;
    for (let i = 0; i < characters.length; i++) {
        const char = characters[i];
        const charType = getCharacterType(char);
        // 根據字符類型選擇設置
        let settings = null;
        if (charType === 'chinese') {
            settings = chineseSettings;
        }
        else if (charType === 'english') {
            settings = englishSettings;
        }
        else if (charType === 'number') {
            settings = numberSettings;
        }
        // 檢查是否需要開始新段落
        const needNewSegment = !currentSegment ||
            currentSegment.type !== charType ||
            !settingsEqual(currentSegment.settings, settings);
        if (needNewSegment) {
            // 完成當前段落
            if (currentSegment) {
                currentSegment.end = i;
                segments.push(currentSegment);
            }
            // 開始新段落
            currentSegment = {
                type: charType,
                start: i,
                end: i + 1,
                settings: settings
            };
        }
        else {
            // 延續當前段落
            currentSegment.end = i + 1;
        }
    }
    // 完成最後一個段落
    if (currentSegment) {
        segments.push(currentSegment);
    }
    return segments;
}
// 比較兩個設置是否相同
function settingsEqual(settings1, settings2) {
    if (!settings1 && !settings2)
        return true;
    if (!settings1 || !settings2)
        return false;
    if (settings1.type !== settings2.type)
        return false;
    if (settings1.type === 'textStyle') {
        return settings1.styleId === settings2.styleId;
    }
    else if (settings1.type === 'font') {
        return settings1.fontFamily === settings2.fontFamily &&
            settings1.fontWeight === settings2.fontWeight &&
            settings1.fontSize === settings2.fontSize;
    }
    return false;
}
// 載入文字節點中所有現有的字體
function loadExistingFontsInNode(node) {
    return __awaiter(this, void 0, void 0, function* () {
        const uniqueFonts = new Set();
        const characters = node.characters;
        // 收集所有不同的字體
        for (let i = 0; i < characters.length; i++) {
            try {
                const fontName = node.getRangeFontName(i, i + 1);
                if (typeof fontName === 'object' && fontName.family && fontName.style) {
                    uniqueFonts.add(`${fontName.family}|${fontName.style}`);
                }
            }
            catch (error) {
                // 忽略單個字符的錯誤
            }
        }
        // 載入所有發現的字體
        const loadPromises = Array.from(uniqueFonts).map(fontKey => {
            const [family, style] = fontKey.split('|');
            return figma.loadFontAsync({ family, style }).catch(err => {
                console.error(`載入現有字體失敗 ${family} ${style}:`, err);
                return null;
            });
        });
        yield Promise.all(loadPromises);
    });
}
// 自動選擇最接近的字重
function getClosestFontWeight(targetFamily, availableFonts, originalWeight) {
    if (!availableFonts[targetFamily]) {
        return null;
    }
    const weights = availableFonts[targetFamily];
    // 如果提供了原始字重，並且目標字體家族有相同的字重，優先使用
    if (originalWeight && weights.indexOf(originalWeight) !== -1) {
        console.log(`保持原始字重: ${originalWeight}`);
        return originalWeight;
    }
    // 如果原始字重不存在，嘗試找到相似的字重
    if (originalWeight) {
        const similarWeights = findSimilarWeights(originalWeight, weights);
        if (similarWeights.length > 0) {
            console.log(`找到相似字重: ${similarWeights[0]} (原始: ${originalWeight})`);
            return similarWeights[0];
        }
    }
    // 最後使用預設優先順序
    const weightPriority = [
        'Regular', 'Medium', 'SemiBold', 'Semi Bold', 'Semibold',
        'Bold', 'Light', 'Black', 'Thin', 'ExtraLight', 'ExtraBold',
        'Heavy', 'UltraLight', 'UltraBold'
    ];
    for (const preferredWeight of weightPriority) {
        if (weights.indexOf(preferredWeight) !== -1) {
            return preferredWeight;
        }
    }
    // 如果沒有找到標準字重，返回第一個可用的字重
    return weights[0] || null;
}
// 尋找相似字重
function findSimilarWeights(originalWeight, availableWeights) {
    // 字重分組：相似的字重會優先互相替代
    const weightGroups = {
        thin: ['Thin', 'UltraLight', 'ExtraLight'],
        light: ['Light', 'ExtraLight'],
        regular: ['Regular', 'Normal', 'Book'],
        medium: ['Medium', 'SemiBold', 'Semi Bold', 'Semibold'],
        bold: ['Bold', 'SemiBold', 'Semi Bold', 'Semibold'],
        heavy: ['Black', 'Heavy', 'ExtraBold', 'UltraBold', 'Bold']
    };
    // 找到原始字重所屬的組
    let targetGroup = null;
    for (const groupName in weightGroups) {
        const groupWeights = weightGroups[groupName];
        if (groupWeights.indexOf(originalWeight) !== -1) {
            targetGroup = groupWeights;
            break;
        }
    }
    if (!targetGroup)
        return [];
    // 在可用字重中尋找同組的字重
    const similarWeights = [];
    for (const weight of targetGroup) {
        if (availableWeights.indexOf(weight) !== -1) {
            similarWeights.push(weight);
        }
    }
    return similarWeights;
}
// 初始化
loadTextStyles();
loadAvailableFonts();
loadPresets();
// 啟用所有頁面的 documentchange 事件
figma.loadAllPagesAsync();
// 遞歸查找所有文字圖層的函式
function findAllTextNodes(nodes) {
    const textNodes = [];
    function traverse(node) {
        if (node.type === 'TEXT') {
            textNodes.push(node);
        }
        else if ('children' in node) {
            // 如果節點有子節點，遞歸檢查每個子節點
            for (const child of node.children) {
                traverse(child);
            }
        }
    }
    for (const node of nodes) {
        traverse(node);
    }
    return textNodes;
}
// 監聽選擇改變
figma.on('selectionchange', () => {
    const selection = figma.currentPage.selection;
    const textNodes = findAllTextNodes(selection);
    const hasTextNode = textNodes.length > 0;
    figma.ui.postMessage({
        type: 'selectionChange',
        hasTextNode: hasTextNode
    });
});
// 監聽文檔變化以實現即時轉換 (總是啟用)
figma.on('documentchange', (event) => __awaiter(void 0, void 0, void 0, function* () {
    // 只檢查是否為插件自己做的修改
    if (isPluginModifying) {
        return;
    }
    // 檢查變化是否為文字相關
    for (const change of event.documentChanges) {
        if (change.type === 'PROPERTY_CHANGE') {
            const node = yield figma.getNodeByIdAsync(change.id);
            // 檢查是否為文字節點且字符內容有變化
            if (node && node.type === 'TEXT' && change.properties.indexOf('characters') !== -1) {
                console.log('檢測到文字變化:', node.id);
                // 直接對這個文字節點進行轉換
                debouncedRealtimeConversionForNode(node);
            }
        }
    }
}));
// 處理來自 UI 的訊息
figma.ui.onmessage = (msg) => __awaiter(void 0, void 0, void 0, function* () {
    if (msg.type === 'applyStyles') {
        const selection = figma.currentPage.selection;
        const textNodes = findAllTextNodes(selection);
        if (textNodes.length === 0) {
            figma.notify('請選擇包含文字圖層的元素');
            return;
        }
        const chineseSettings = msg.chineseSettings;
        const englishSettings = msg.englishSettings;
        const numberSettings = msg.numberSettings;
        // 記錄最後套用的設定供即時轉換使用
        lastAppliedSettings = {
            chineseSettings,
            englishSettings,
            numberSettings
        };
        try {
            for (const node of textNodes) {
                // 首先載入節點中所有現有的字體
                yield loadExistingFontsInNode(node);
                const characters = node.characters;
                // 收集所有需要加載的字體
                const fontsToLoad = new Set();
                // 分析文字並收集字體需求
                const segments = analyzeTextSegments(characters, chineseSettings, englishSettings, numberSettings);
                console.log('分析結果:', segments); // 除錯用
                // 收集所有需要載入的字體
                for (const segment of segments) {
                    if (segment.settings && segment.settings.type === 'font' && segment.settings.fontFamily) {
                        // 自動選擇字重（如果未指定）
                        let fontWeight = segment.settings.fontWeight;
                        if (!fontWeight) {
                            // 獲取該段落中第一個字符的原始字重
                            let originalWeight = null;
                            try {
                                const firstCharFont = node.getRangeFontName(segment.start, segment.start + 1);
                                if (typeof firstCharFont === 'object' && firstCharFont.style) {
                                    originalWeight = firstCharFont.style;
                                }
                            }
                            catch (error) {
                                // 忽略錯誤
                            }
                            fontWeight = getClosestFontWeight(segment.settings.fontFamily, fontFamiliesData, originalWeight || undefined);
                        }
                        if (fontWeight) {
                            fontsToLoad.add(`${segment.settings.fontFamily}|${fontWeight}`);
                        }
                    }
                }
                console.log('需要載入的字體:', Array.from(fontsToLoad)); // 除錯用
                // 載入所有需要的字體
                const fontLoadPromises = Array.from(fontsToLoad).map(fontKey => {
                    const [family, style] = fontKey.split('|');
                    return figma.loadFontAsync({ family, style }).catch(err => {
                        console.error(`無法載入字體 ${family} ${style}:`, err);
                        return null;
                    });
                });
                yield Promise.all(fontLoadPromises);
                // 按段落應用字體樣式
                for (const segment of segments) {
                    if (segment.settings) {
                        try {
                            console.log(`處理段落: "${characters.slice(segment.start, segment.end)}" (${segment.start}-${segment.end}), 類型: ${segment.type}`);
                            if (segment.settings.type === 'textStyle' && segment.settings.styleId) {
                                console.log(`套用文字樣式: ${segment.settings.styleId}`);
                                node.setRangeTextStyleId(segment.start, segment.end, segment.settings.styleId);
                            }
                            else if (segment.settings.type === 'font' && segment.settings.fontFamily) {
                                // 自動選擇字重（如果未指定）
                                let fontWeight = segment.settings.fontWeight;
                                if (!fontWeight) {
                                    // 獲取該段落中第一個字符的原始字重
                                    let originalWeight = null;
                                    try {
                                        const firstCharFont = node.getRangeFontName(segment.start, segment.start + 1);
                                        if (typeof firstCharFont === 'object' && firstCharFont.style) {
                                            originalWeight = firstCharFont.style;
                                        }
                                    }
                                    catch (error) {
                                        // 忽略錯誤
                                    }
                                    fontWeight = getClosestFontWeight(segment.settings.fontFamily, fontFamiliesData, originalWeight || undefined);
                                    console.log(`自動選擇字重: ${fontWeight} (原始: ${originalWeight})`);
                                }
                                if (fontWeight) {
                                    console.log(`套用字體: ${segment.settings.fontFamily} ${fontWeight}`);
                                    // 設置字體
                                    node.setRangeFontName(segment.start, segment.end, {
                                        family: segment.settings.fontFamily,
                                        style: fontWeight
                                    });
                                    // 設置字體大小
                                    if (segment.settings.fontSize && segment.settings.fontSize !== 'keep') {
                                        const fontSize = parseInt(segment.settings.fontSize);
                                        if (!isNaN(fontSize)) {
                                            console.log(`套用字體大小: ${fontSize}`);
                                            node.setRangeFontSize(segment.start, segment.end, fontSize);
                                        }
                                    }
                                }
                                else {
                                    console.log(`無法找到字體家族的可用字重: ${segment.settings.fontFamily}`);
                                }
                            }
                        }
                        catch (error) {
                            console.error(`處理文字段落 "${characters.slice(segment.start, segment.end)}" 時發生錯誤:`, error);
                            figma.notify(`處理段落時發生錯誤: ${error.message}`);
                        }
                    }
                }
            }
            figma.notify('已應用多語系字型樣式');
        }
        catch (error) {
            console.error('應用樣式失敗:', error);
            figma.notify('應用樣式時發生錯誤');
        }
    }
    else if (msg.type === 'savePreset') {
        const newPreset = {
            id: Date.now().toString(),
            name: msg.name,
            chineseSettings: msg.chineseSettings,
            englishSettings: msg.englishSettings,
            numberSettings: msg.numberSettings
        };
        presets.push(newPreset);
        // 只儲存使用者建立的組合 (排除內建組合)
        const userPresets = presets.filter(preset => !preset.isBuiltin);
        yield figma.clientStorage.setAsync('languagePresets', userPresets);
        figma.ui.postMessage({
            type: 'presets',
            presets: presets
        });
        figma.notify(`已保存預設集：${msg.name}`);
    }
    else if (msg.type === 'deletePreset') {
        // 檢查是否為內建組合
        const presetToDelete = presets.find(p => p.id === msg.presetId);
        if (presetToDelete && presetToDelete.isBuiltin) {
            figma.notify('無法刪除內建預設組合');
            return;
        }
        // 從記憶體中移除
        const filteredPresets = presets.filter(preset => preset.id !== msg.presetId);
        presets = filteredPresets;
        // 只儲存使用者建立的組合 (排除內建組合)
        const userPresets = presets.filter(preset => !preset.isBuiltin);
        yield figma.clientStorage.setAsync('languagePresets', userPresets);
        figma.ui.postMessage({
            type: 'presets',
            presets: presets
        });
        figma.notify('已刪除預設集');
    }
    else if (msg.type === 'loadPreset') {
        const preset = presets.find(p => p.id === msg.presetId);
        if (preset) {
            figma.ui.postMessage({
                type: 'loadedPreset',
                preset: preset
            });
        }
    }
});
